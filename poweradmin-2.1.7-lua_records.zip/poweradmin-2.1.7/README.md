# Poweradmin - a web-based control panel for PowerDNS.

[Poweradmin](http://www.poweradmin.org/) is a friendly web-based DNS administration tool for Bert Hubert's PowerDNS server. The interface has full support for most of the features of PowerDNS. It has full support for all zone types (master,  native and  slave), for  supermasters for automatic provisioning of slave zones, full support for IPv6 and comes with multi-language support.
