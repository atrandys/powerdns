ALTER TABLE zones ADD zone_templ_id INT DEFAULT NULL;
